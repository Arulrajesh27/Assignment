package org.baseclass;

import java.time.Duration;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriver.Navigation;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class BaseClass {
	public static WebDriver driver;
	public static Select s;
	public WebDriver launchBrowser(String browserName) {
		if (browserName.equals("chrome")) {
			driver =new ChromeDriver();
		}else if (browserName=="firefox") {
			driver =new FirefoxDriver();
		}else if (browserName=="edge") {
			driver =new EdgeDriver();
		}
		return driver;
	}
	public void launchurl(String url) {
		driver.get(url);
	}
	public void assertTrue(String message,boolean result) {
		Assert.assertTrue(message, result);
	}
	public void assertEquals(String message,String expected,String actual) {
		Assert.assertEquals(message, expected, actual);
	}
	public void selectOptionIndex(WebElement element,int index) {
		s=new Select(element);
		s.selectByIndex(index);
	}
	public void selectOptionVisibleText(WebElement element,String text) {
		s=new Select(element);
		s.selectByVisibleText(text);
	}
	public void selectOptionValue(WebElement element,String value) {
		s=new Select(element);
		s.selectByValue(value);
	}
	public void maxWindow() {
		driver.manage().window().maximize();
	}
	public void type(WebElement element,String data) {
		element.sendKeys(data);
	}
	public void btnClick(WebElement element) {
		element.click();
	}
	public void quitBrowser() {
		driver.quit();
	}
	public String getPageUrl() {
		String currentUrl = driver.getCurrentUrl();
		return currentUrl;
	}
	public WebElement webDriverWait(WebElement element,int time) {
		WebDriverWait w = new WebDriverWait(driver, Duration.ofSeconds(time));
		WebElement ele = w.until(ExpectedConditions.elementToBeClickable(element));
		return ele;
	}
	public String getPageTitle() {
		String title = driver.getTitle();
		return title;
	}
	public void implicitWait(int time) {
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(time));	
	}
	public String getText(WebElement element) {
		String text = element.getText();
		return text;
	}
	public String getAttribute(WebElement element,String att) {
		String attribute = element.getAttribute(att);
		return attribute;
	}
	public Navigation pageNavigate() {
		Navigation navigate = driver.navigate();
		return navigate;
	}
	public void navigateToUrl(String url) {
		pageNavigate().to(url);
	}
	public void navigateBackPage() {
		pageNavigate().back();
	}
	public void navigateFrontPage() {
		pageNavigate().forward();
	}
	public void pageRefresh() {
		pageNavigate().refresh();
	}
}
