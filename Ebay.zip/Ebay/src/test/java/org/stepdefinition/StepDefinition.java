package org.stepdefinition;

import org.baseclass.BaseClass;
import org.pojo.AllFilterPagePojo;
import org.pojo.HomePagePojo;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;


public class StepDefinition extends BaseClass {
	
@Given("User launch the Ebay application")
public void user_launch_the_ebay_application() {
   /* launchBrowser("chrome");
    implicitWait(20);
    maxWindow();
    navigateToUrl("https://www.ebay.com/");*/
}
@When("User clicks the Shop by Category button")
public void user_clicks_the_shop_by_category_button() {
	HomePagePojo hpp = new HomePagePojo();
	webDriverWait(hpp.getCategory(),20);
	btnClick(hpp.getCategory());
}
@When("User clicks the Cell phones & accessories under Electronics section")
public void user_clicks_the_cell_phones_accessories_under_electronics_section() {
	HomePagePojo hpp = new HomePagePojo();
	implicitWait(20);
	btnClick(hpp.getCellPhoneAndAccessories());
}
@When("User clicks the Cell Phones & SmartPhones")
public void user_clicks_the_cell_phones_smart_phones() {
	HomePagePojo hpp = new HomePagePojo();
	implicitWait(20);
	btnClick(hpp.getCellPhoneAndSmartphones());
}
@When("User clicks the All Filter")
public void user_clicks_the_all_filter() {
	HomePagePojo hpp = new HomePagePojo();
	webDriverWait(hpp.getAllFilters(), 20);
	btnClick(hpp.getAllFilters());
}
@When("User clicks the Condition")
public void user_clicks_the_condition() {
	AllFilterPagePojo afp= new AllFilterPagePojo();
	webDriverWait(afp.getConditionFilter(), 20);
	btnClick(afp.getConditionFilter());
}
@When("User selects the conditions")
public void user_selects_the_conditions() {
	AllFilterPagePojo afp= new AllFilterPagePojo();
	webDriverWait(afp.getNewCheckBox(),20);
	btnClick(afp.getNewCheckBox());
	btnClick(afp.getOpenBoxCheckBox());
	btnClick(afp.getUsedCheckBox());
}
@When("User clicks the price")
public void user_clicks_the_price() {
	AllFilterPagePojo afp= new AllFilterPagePojo();
	webDriverWait(afp.getPriceFilter(), 20);
	btnClick(afp.getPriceFilter());
}
@When("User set the price difference")
public void user_set_the_price_difference() {
	AllFilterPagePojo afp= new AllFilterPagePojo();
	type(afp.getMinimumPrice(), "20");
	type(afp.getMaximumPrice(), "1000");
}
@When("User clciks the Item Location")
public void user_clciks_the_item_location() {
	AllFilterPagePojo afp= new AllFilterPagePojo();
	webDriverWait(afp.getItemLocationFilter(), 20);
    btnClick(afp.getItemLocationFilter());
}
@When("User selects the location")
public void user_selects_the_location() {
	AllFilterPagePojo afp= new AllFilterPagePojo();
	btnClick(afp.getRadioButtonNorthAmerica());
}
@When("User clicks apply button")
public void user_clicks_apply_button() {
	AllFilterPagePojo afp= new AllFilterPagePojo();
	webDriverWait(afp.getApplyButton(), 20);
	btnClick(afp.getApplyButton());
}
@Then("User verifies that the filter tags are applied")
public void user_verifies_that_the_filter_tags_are_applied() {
	AllFilterPagePojo afp= new AllFilterPagePojo();
	webDriverWait(afp.getFilterAppliedButton(), 20);
	btnClick(afp.getFilterAppliedButton());
	assertTrue("Applied Condition filter New Not Matching", getText(afp.getVerifyConditionFilter1()).contains("New"));
	assertTrue("Applied Condition filter Open Box Not Matching", getText(afp.getVerifyConditionFilter2()).contains("Open box"));
	assertTrue("Applied Condition filter Used Not Matching",getText(afp.getVerifyConditionFilter3()).contains("Used"));
	assertTrue("Applied Price filter $20 to $1000 Not Matching", getText(afp.getVerifyPriceFilter()).contains("$20.00 to $1,000.00"));
	assertTrue("Applied Item Location filter North America Not Matching", getText(afp.getVerifyItemLocationFilter()).contains("North America"));
}
@When("User Enters the product name in search bar")
public void user_enters_the_product_name_in_search_bar() {
	HomePagePojo hpp = new HomePagePojo();
	type(hpp.getSearchField(),"Macbook");
}
@When("User clicks the button to search category and select")
public void user_clicks_the_button_to_change_the_search_category() {
	HomePagePojo hpp = new HomePagePojo();
	selectOptionValue(hpp.getSearchCategory(), "58058");
}
@When("User clicks the search button")
public void user_clicks_the_search_button() {
	HomePagePojo hpp = new HomePagePojo();
	webDriverWait(hpp.getsearchButton(), 20);
	btnClick(hpp.getsearchButton());
}
@Then("User verifies the page loads completely")
public void user_verifies_the_page_loads_completely() {
	
	assertTrue("Page did not load completely", getPageTitle().contains("Computers/Tablets"));
}
@Then("User verifies the first result name matches with the search sting")
public void user_verifies_the_first_result_name_matches_with_the_search_sting() {
	HomePagePojo hpp = new HomePagePojo();
	assertTrue(getPageTitle(), getText(hpp.getfirstProduct()).contains(getAttribute(hpp.getSearchField(), "value")));
}
}
