package org.runner;

import org.junit.runner.RunWith;
import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(features ={"src\\test\\resources\\Features\\ProductViaSearch.feature",
"src\\test\\resources\\Features\\ProductViaCategory.feature"}
,glue="org.stepdefinition",monochrome = true,dryRun =false,
plugin= {"pretty","junit:target\\Ebay.xml",
		"html:target\\Ebay.html",
		"json:target\\Ebay.json"})
public class TestRunner {

}
