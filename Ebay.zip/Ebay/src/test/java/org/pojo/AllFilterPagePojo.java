package org.pojo;

import org.baseclass.BaseClass;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.PageFactory;

public class AllFilterPagePojo extends BaseClass {
public AllFilterPagePojo() {
	
		PageFactory.initElements(driver, this);
	}

@FindBy(xpath="(//span[text()='Condition'])[2]")
private WebElement conditionFilter;
@FindBy(xpath="(//span[@class='checkbox cbx x-refine__multi-select-checkbox '])[1]")
private WebElement newCheckBox;
@FindBy(xpath="(//span[@class='checkbox cbx x-refine__multi-select-checkbox '])[2]")
private WebElement openBoxCheckBox;
@FindBy(xpath="(//span[@class='checkbox cbx x-refine__multi-select-checkbox '])[7]")
private WebElement usedCheckBox;
@FindBy(xpath ="//div[@data-aspecttitle='price']")
private WebElement priceFilter;
@FindBy(xpath ="(//input[@pattern='\\d*'])[1]")
private WebElement minimumPrice;
@FindBy(xpath ="(//input[@pattern='\\d*'])[2]")
private WebElement maximumPrice;
@FindBy(xpath ="//span[text()='Item Location']")
private WebElement itemLocationFilter;
@FindBy(xpath ="//input[@value='North America']")
private WebElement radioButtonNorthAmerica;
@FindBy(xpath ="//button[text()='Apply']")
private WebElement applyButton;
@FindBy(xpath ="(//div[@class='x-flyout brm__flyout brm__flyout--selected'])[1]")
private WebElement filterAppliedButton;
@FindBys({@FindBy(xpath ="(//span[@class='brm__item-label'])[1]"),@FindBy(xpath ="//span[contains(text(),'Condition:')]")})
private WebElement verifyConditionFilter1;
@FindBys({@FindBy(xpath ="(//span[@class='brm__item-label'])[2]"),@FindBy(xpath ="//span[contains(text(),'Open box')]")})
private WebElement verifyConditionFilter2;
@FindBys({@FindBy(xpath ="(//span[@class='brm__item-label'])[3]"),@FindBy(xpath ="//span[contains(text(),'Used')]")})
private WebElement verifyConditionFilter3;
@FindBys({@FindBy(xpath ="(//span[@class='brm__item-label'])[4]"),@FindBy(xpath ="//span[contains(text(),'Price:')]")})
private WebElement verifyPriceFilter;
@FindBys({@FindBy(xpath ="(//span[@class='brm__item-label'])[5]"),@FindBy(xpath ="//span[contains(text(),'Item Location:')]")})
private WebElement verifyItemLocationFilter;

public WebElement getOpenBoxCheckBox() {
	return openBoxCheckBox;
}
public WebElement getUsedCheckBox() {
	return usedCheckBox;
}
public WebElement getConditionFilter() {
	return conditionFilter;
}
public WebElement getNewCheckBox() {
	return newCheckBox;
}
public WebElement getPriceFilter() {
	return priceFilter;
}
public WebElement getMinimumPrice() {
	return minimumPrice;
}
public WebElement getMaximumPrice() {
	return maximumPrice;
}
public WebElement getItemLocationFilter() {
	return itemLocationFilter;
}
public WebElement getRadioButtonNorthAmerica() {
	return radioButtonNorthAmerica;
}
public WebElement getApplyButton() {
	return applyButton;
}
public WebElement getFilterAppliedButton() {
	return filterAppliedButton;
}
public WebElement getVerifyConditionFilter1() {
	return verifyConditionFilter1;
}
public WebElement getVerifyConditionFilter2() {
	return verifyConditionFilter2;
}
public WebElement getVerifyConditionFilter3() {
	return verifyConditionFilter3;
}
public WebElement getVerifyPriceFilter() {
	return verifyPriceFilter;
}
public WebElement getVerifyItemLocationFilter() {
	return verifyItemLocationFilter;
}
}
