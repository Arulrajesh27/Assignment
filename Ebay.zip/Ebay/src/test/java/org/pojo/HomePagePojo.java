package org.pojo;

import org.baseclass.BaseClass;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;


public class HomePagePojo extends BaseClass {
	
public HomePagePojo() {
	PageFactory.initElements(driver, this);
}
@FindBy(xpath ="//button[@id='gh-shop-a']")
private WebElement category;
@FindBy(xpath ="//a[text()='Cell phones & accessories']")
private WebElement cellPhoneAndAccessories;
@FindBy(xpath ="//a[text()='Cell Phones & Smartphones']")
private WebElement cellPhoneAndSmartphones;
@FindBy(xpath ="//button[text()='All Filters']")
private WebElement allFilters;
@FindBy(xpath ="//input[@type='text']")
private WebElement searchField;
@FindBy(xpath ="//select[@name='_sacat']")
private WebElement searchCategory;
@FindBy(xpath ="//input[@type='submit']")
private WebElement searchButton;
@FindBy(xpath ="(//div[@class='s-item__title'])[2]")
private WebElement firstProduct;

public WebElement getfirstProduct() {
	return firstProduct;
}
public WebElement getSearchField() {
	return searchField;
}
public WebElement getsearchButton() {
	return searchButton;
}
public WebElement getSearchCategory() {
	return searchCategory;
}
public WebElement getCategory() {
	return category;
}
public WebElement getCellPhoneAndAccessories() {
	return cellPhoneAndAccessories;
}
public WebElement getCellPhoneAndSmartphones() {
	return cellPhoneAndSmartphones;
}
public WebElement getAllFilters() {
	return allFilters;
}
}
